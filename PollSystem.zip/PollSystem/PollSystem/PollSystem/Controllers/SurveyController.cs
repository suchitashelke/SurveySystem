﻿using BLL;
using DAL;
using PollSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PollSystem.Controllers
{
    [Authorize]
    public class SurveyController : Controller
    {
        IPollService pollservice;
        IPollQuestionService pollquestionservice;
        IUserAnswerService useranswerservice;
        IUserPollService userpollservice;
        IPollQuesAnswersService pollquesanswersservice;

        public SurveyController(IPollService pollservice, IPollQuestionService pollquestionservice, IUserAnswerService useranswerservice, IUserPollService userpollservice, IPollQuesAnswersService pollquesanswersservice)
        {
            this.pollservice = pollservice;
            this.pollquestionservice = pollquestionservice;
            this.useranswerservice = useranswerservice;
            this.userpollservice = userpollservice;
            this.pollquesanswersservice = pollquesanswersservice;
        }
       
        public ActionResult Index()
        {
            try
            {
                if (Session[Constants.LoginUser] != null)
                {
                    User user = (User)Session[Constants.LoginUser];
                    ViewBag.PollList = GetPollList(user.Id);
                    return View();
                }
            }
            catch (Exception ex) { }

            return RedirectToAction("LogOut", "Account");
        }

        private List<SelectListItem> GetPollList(short userid)
        {
            try
            {
                List<Poll> listPoll = pollservice.GetUserPoll(userid);

                List<SelectListItem> ddlPollList = listPoll
                                                    .Select(item => new SelectListItem
                                                    {
                                                        Value = item.Id.ToString(),
                                                        Text = item.Title,
                                                        Selected = "-1" == item.Id.ToString() ? true : false
                                                    })
                                                    .ToList();

                return ddlPollList;
            }
            catch (Exception ex) { }
            return null;
        }

        public ActionResult GetQuestionsWithAnswers(string pollid)
        {
            try
            {
                if (!string.IsNullOrEmpty(pollid))
                {
                    List<PollQuestion> listQuestion = pollquestionservice.GetQuestionsByPollId(Convert.ToInt16(pollid));
                    ViewBag.listPollQuestion = listQuestion;
                    return PartialView("~/Views/Shared/_SurveyQuestion.cshtml");
                }
            }
            catch (Exception ex) { }

            return null;            
        }

        public ActionResult submitSurvey(FormCollection collection)
        {
            try
            {
                if (collection != null)
                {
                    User user = (User)Session[Constants.LoginUser];
                    StringBuilder sb = new StringBuilder();

                    foreach (var key in collection.Keys)
                    {
                        if (key.ToString().ToLower().StartsWith("ansfor"))
                            sb.Append(collection[key.ToString()] + ",");
                    }
                    userpollservice.Insert(user.Id, Convert.ToInt16(collection["PollId"]));
                    useranswerservice.InsertUserAnswers(user.Id, sb.ToString());
                    ViewBag.PollList = GetPollList(user.Id);

                    return Json(collection["PollId"], JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex) { }

            return Json(false, JsonRequestBehavior.AllowGet);            
        }

        public ActionResult GetQuestions(string pollid)
        {
            try
            {
                if (!string.IsNullOrEmpty(pollid))
                {
                    List<PollQuestion> listQuestion = pollquestionservice.GetOnlyQuestionsByPollId(Convert.ToInt16(pollid));

                    if (listQuestion!=null)
                        return Json(listQuestion.ToList(), JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex) { }

            return null;
        }

        public JsonResult GetChartData(string questionid)
        {
            try
            {
                if (!string.IsNullOrEmpty(questionid))
                {
                    List<AnswerPercentage> list = pollquesanswersservice.GetAnswerPercentage(Convert.ToInt16(questionid));                    
                    List<ChartData> listChartData = new List<ChartData>();
                    ChartData objChartData;
                    foreach (AnswerPercentage obj in list)
                    {
                        objChartData = new ChartData();
                        objChartData.Item = obj.Percentage;
                        objChartData.Value = obj.Answer;
                        listChartData.Add(objChartData);
                    }
                    return Json(listChartData.ToList(), JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex) { }

            return null;           
        }       
    }
}
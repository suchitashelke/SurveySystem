﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public interface IPollQuesAnswersService
    {
        List<PollQuesAnswer> GetAnswersByQuestionId(short questionid);
        PollQuesAnswer GetAnswerById(short answerid);
        int UpdateAnswer(PollQuesAnswer answer);
        List<AnswerPercentage> GetAnswerPercentage(short questionid);
    }

    public class PollQuesAnswersService : IPollQuesAnswersService
    {
        IRepository<PollQuesAnswer> repository;

        public PollQuesAnswersService(IRepository<PollQuesAnswer> repository)
        {
            this.repository = repository;
        }

        public List<PollQuesAnswer> GetAnswersByQuestionId(short questionid)
        {
            return repository.FindAll(a => a.QuestionId == questionid) as List<PollQuesAnswer>;
        }

        public PollQuesAnswer GetAnswerById(short answerid)
        {
            return repository.Get(answerid);
        }

        public int UpdateAnswer(PollQuesAnswer answer)
        {
            return repository.Update(answer, answer.Id);
        }

        public List<AnswerPercentage> GetAnswerPercentage(short questionid)
        {
            SqlParameter questionidParam = new SqlParameter("@QuestionId", questionid);
            object[] parameters = new object[] { questionidParam };
            return repository.ExecuteSqlQuery<AnswerPercentage>("exec spGetAnswerPercentage @QuestionId", parameters) as List<AnswerPercentage>;
        }
    }
}
